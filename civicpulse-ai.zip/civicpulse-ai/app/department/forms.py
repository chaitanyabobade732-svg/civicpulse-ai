from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, Optional
from app.auth.forms import CIVIC_CATEGORIES

STATUS_CHOICES = [
    ('Acknowledged', 'Acknowledge Grievance (Day 2 SLA Satisfied)'),
    ('In Progress', 'Mark Work In Progress'),
    ('On Hold', 'Put On Hold (Requires Stated Reason)'),
    ('Resolved — Awaiting Citizen Verification', 'Mark Work Completed (Awaiting Citizen Verification)'),
    ('Rejected — With Reason', 'Reject Grievance (Requires Legitimate Justification)')
]

PRIORITY_CHOICES = [
    ('Low', 'Low Priority'),
    ('Medium', 'Medium Priority'),
    ('High', 'High Priority'),
    ('Urgent', 'Urgent Public Hazard')
]

class ManageComplaintForm(FlaskForm):
    status = SelectField('Update Workflow Status', choices=STATUS_CHOICES, validators=[DataRequired()])
    priority = SelectField('Confirmed / Adjusted Priority', choices=PRIORITY_CHOICES, validators=[DataRequired()])
    assigned_staff_id = SelectField('Assign Field Staff / Junior Engineer', coerce=int, validators=[Optional()])
    progress_notes = TextAreaField('Departmental Action Notes / Progress Remarks', validators=[
        DataRequired(message="Please provide meaningful notes explaining action taken or status change."),
        Length(min=5, max=1000)
    ])
    resolution_proof = FileField('Upload Resolution Evidence Photograph (JPG/PNG/WEBP)', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'webp'], 'Only image files allowed for resolution proof!')
    ])
    submit = SubmitField('Update Grievance Status')

class ReassignCategoryForm(FlaskForm):
    new_category = SelectField('Proposed Correct Category', choices=CIVIC_CATEGORIES, validators=[DataRequired()])
    reassignment_reason = TextAreaField('Mandatory Justification for Department Transfer', validators=[
        DataRequired(message="Justification for category change is required."),
        Length(min=10, max=500)
    ])
    submit = SubmitField('Submit Category Transfer')
