import os
from datetime import datetime, timezone, timedelta
from flask import Flask, render_template, session, request
from config import config_by_name
from app.extensions import db, login_manager, csrf, migrate
from app.translations.languages import translate, get_current_language

def create_app(config_name=None):
    """CivicPulse AI Application Factory."""
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')

    app = Flask(__name__)
    app.config.from_object(config_by_name.get(config_name, config_by_name['default']))

    # Ensure upload directories exist
    upload_dirs = [
        app.config['UPLOAD_FOLDER'],
        os.path.join(app.config['UPLOAD_FOLDER'], 'complaints'),
        os.path.join(app.config['UPLOAD_FOLDER'], 'verifications'),
        os.path.join(app.config['UPLOAD_FOLDER'], 'resolutions')
    ]
    for d in upload_dirs:
        os.makedirs(d, exist_ok=True)

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    migrate.init_app(app, db)

    # Register Blueprints
    from app.auth import auth_bp
    from app.complaints import complaints_bp
    from app.citizen import citizen_bp
    from app.department import dept_bp
    from app.supervisor import supervisor_bp
    from app.department_head import dept_head_bp
    from app.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(complaints_bp)
    app.register_blueprint(citizen_bp)
    app.register_blueprint(dept_bp)
    app.register_blueprint(supervisor_bp)
    app.register_blueprint(dept_head_bp)
    app.register_blueprint(admin_bp)

    # Context Processors for Jinja
    @app.context_processor
    def inject_globals():
        return {
            't': translate,
            'current_lang': get_current_language(),
            'current_year': datetime.now().year
        }

    # Custom Jinja Filters for Indian Standard Time (IST = UTC+5:30) and formatting
    @app.template_filter('ist_time')
    def ist_time_filter(dt, format='%d %b %Y, %I:%M %p'):
        if not dt:
            return '—'
        # Convert UTC to IST (+5 hours 30 mins)
        ist_dt = dt + timedelta(hours=5, minutes=30)
        return ist_dt.strftime(format) + ' IST'

    @app.template_filter('status_badge')
    def status_badge_filter(status):
        badges = {
            'Submitted': 'badge-submitted',
            'Under AI Analysis': 'badge-ai',
            'Awaiting Department Assignment': 'badge-warning',
            'Assigned': 'badge-info',
            'Acknowledged': 'badge-acknowledged',
            'In Progress': 'badge-progress',
            'On Hold': 'badge-warning',
            'Resolved — Awaiting Citizen Verification': 'badge-resolved',
            'Closed': 'badge-closed',
            'Reopened': 'badge-danger',
            'Rejected — With Reason': 'badge-rejected'
        }
        return badges.get(status, 'badge-secondary')

    @app.template_filter('priority_badge')
    def priority_badge_filter(priority):
        badges = {
            'Urgent': 'badge-urgent',
            'High': 'badge-high',
            'Medium': 'badge-medium',
            'Low': 'badge-low'
        }
        return badges.get(priority, 'badge-secondary')

    # Error Handlers
    @app.errorhandler(403)
    def forbidden(e):
        return render_template('shared/403.html'), 403

    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('shared/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('shared/500.html'), 500

    return app
