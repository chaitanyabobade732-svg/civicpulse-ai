from app.citizen.routes import citizen_bp

__all__ = ['citizen_bp']
