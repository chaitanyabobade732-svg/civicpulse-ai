import os
import random
import string
import uuid
from datetime import datetime, timezone, timedelta
from werkzeug.utils import secure_filename
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_required, current_user
from app.auth.decorators import citizen_required
from app.models import Complaint, ComplaintImage, ComplaintStatusHistory, AIAnalysisResult, Notification, AuditLog, utc_now
from app.services.ai_analyzer import AIComplaintAnalyzer
from app.services.department_router import DepartmentRouter
from app.services.notification_service import NotificationService
from app.services.duplicate_detector import DuplicateDetector
from app.citizen.forms import ComplaintSubmissionForm, ReopenComplaintForm, EditComplaintForm
from app.extensions import db

citizen_bp = Blueprint('citizen', __name__, url_prefix='/citizen')

def generate_complaint_id():
    """Generate human-readable Indian public grievance tracking ID e.g. CP-2026-K9X42."""
    year = datetime.now().year
    suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"CP-{year}-{suffix}"

@citizen_bp.route('/dashboard')
@login_required
@citizen_required
def dashboard():
    """Citizen central portal dashboard."""
    user_id = current_user.id
    now = utc_now()

    total_submitted = Complaint.query.filter_by(citizen_id=user_id).count()
    open_count = Complaint.query.filter(
        Complaint.citizen_id == user_id,
        Complaint.status.in_(['Submitted', 'Under AI Analysis', 'Awaiting Department Assignment', 'Assigned', 'Reopened'])
    ).count()
    in_progress_count = Complaint.query.filter(
        Complaint.citizen_id == user_id,
        Complaint.status.in_(['Acknowledged', 'In Progress', 'On Hold'])
    ).count()
    resolved_count = Complaint.query.filter(
        Complaint.citizen_id == user_id,
        Complaint.status.in_(['Resolved — Awaiting Citizen Verification', 'Closed'])
    ).count()
    overdue_count = Complaint.query.filter(
        Complaint.citizen_id == user_id,
        Complaint.status.notin_(['Resolved — Awaiting Citizen Verification', 'Closed', 'Rejected — With Reason']),
        Complaint.deadline_day2 != None,
        Complaint.deadline_day2 < now
    ).count()

    recent_complaints = Complaint.query.filter_by(citizen_id=user_id).order_by(Complaint.created_at.desc()).limit(5).all()
    recent_notifications = current_user.notifications.order_by(Notification.created_at.desc()).limit(6).all()

    return render_template(
        'citizen/dashboard.html',
        total_submitted=total_submitted,
        open_count=open_count,
        in_progress_count=in_progress_count,
        resolved_count=resolved_count,
        overdue_count=overdue_count,
        recent_complaints=recent_complaints,
        recent_notifications=recent_notifications
    )

@citizen_bp.route('/file-complaint', methods=['GET', 'POST'])
@login_required
@citizen_required
def file_complaint():
    """Register a new public civic grievance with AI triage and routing."""
    form = ComplaintSubmissionForm()
    
    # Pre-fill citizen profile defaults
    if request.method == 'GET':
        if current_user.state:
            form.state.data = current_user.state
        if current_user.district:
            form.district.data = current_user.district
        if current_user.city_village:
            form.city_village.data = current_user.city_village

    if form.validate_on_submit():
        cid = generate_complaint_id()
        now = utc_now()

        # Day 2 SLA: 48h, Day 4 SLA: 96h
        sla_day2 = now + timedelta(hours=current_app.config.get('SLA_DAY2_HOURS', 48))
        sla_day4 = now + timedelta(hours=current_app.config.get('SLA_DAY4_HOURS', 96))

        complaint = Complaint(
            complaint_id=cid,
            citizen_id=current_user.id,
            title=form.title.data.strip(),
            description=form.description.data.strip(),
            category=form.category.data,
            state=form.state.data,
            district=form.district.data.strip(),
            city_village=form.city_village.data.strip(),
            address_landmark=form.address_landmark.data.strip(),
            latitude=form.latitude.data,
            longitude=form.longitude.data,
            status='Submitted',
            priority='Medium', # Will be refined by AI analysis
            deadline_day2=sla_day2,
            deadline_day4=sla_day4,
            created_at=now
        )
        db.session.add(complaint)
        db.session.flush()

        # Handle photo uploads
        saved_first_image_path = None
        if form.photos.data:
            upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'complaints')
            os.makedirs(upload_dir, exist_ok=True)
            for file_storage in form.photos.data[:3]: # Max 3 images
                if file_storage and file_storage.filename:
                    ext = os.path.splitext(file_storage.filename)[1].lower()
                    if ext in ['.jpg', '.jpeg', '.png', '.webp']:
                        rand_filename = f"comp_{uuid.uuid4().hex[:12]}{ext}"
                        full_path = os.path.join(upload_dir, rand_filename)
                        file_storage.save(full_path)
                        rel_path = os.path.join('uploads', 'complaints', rand_filename).replace('\\', '/')
                        if not saved_first_image_path:
                            saved_first_image_path = full_path

                        c_img = ComplaintImage(
                            complaint_id=complaint.id,
                            image_type='citizen_submission',
                            file_path=rel_path,
                            original_filename=secure_filename(file_storage.filename),
                            uploaded_by_id=current_user.id
                        )
                        db.session.add(c_img)

        # 1. Trigger AI Complaint Analyzer
        analyzer = AIComplaintAnalyzer()
        try:
            ai_data = analyzer.analyze_complaint(
                title=complaint.title,
                description=complaint.description,
                user_category=complaint.category,
                location=f"{complaint.district}, {complaint.state}",
                image_path=saved_first_image_path
            )
        except Exception as e:
            current_app.logger.error(f"AI Analyzer exception: {e}")
            ai_data = analyzer._rule_based_analysis(
                title=complaint.title,
                description=complaint.description,
                user_category=complaint.category,
                location=f"{complaint.district}, {complaint.state}",
                image_path=saved_first_image_path
            )

        # Store AI Analysis Result
        ai_record = AIAnalysisResult(
            complaint_id=complaint.id,
            is_real_ai=ai_data.get('is_real_ai', False),
            model_name=ai_data.get('model_name', 'Rule Engine'),
            analysis_type=ai_data.get('analysis_type', 'Rule-based analysis'),
            recommended_category=ai_data.get('recommended_category', complaint.category),
            recommended_department_code=ai_data.get('recommended_department_code'),
            suggested_priority=ai_data.get('suggested_priority', 'Medium'),
            confidence_score=ai_data.get('confidence_score', 0.85),
            explanation=ai_data.get('explanation', ''),
            safety_risks=ai_data.get('safety_risks', ''),
            potential_duplicates_summary=ai_data.get('potential_duplicates_summary', ''),
            recommended_next_action=ai_data.get('recommended_next_action', ''),
            raw_response=ai_data.get('raw_response', '')
        )
        db.session.add(ai_record)

        # Refine complaint priority from AI recommendation
        complaint.priority = ai_data.get('suggested_priority', 'Medium')

        # 2. Automatic Department Routing
        target_dept = DepartmentRouter.route_complaint(
            category=complaint.category,
            state=complaint.state,
            district=complaint.district,
            city_village=complaint.city_village
        )

        if target_dept:
            complaint.department_id = target_dept.id
            complaint.status = 'Assigned'
            status_note = f"Grievance routed automatically to {target_dept.name} ({target_dept.code})."
        else:
            complaint.status = 'Awaiting Department Assignment'
            status_note = "Awaiting manual administrative department routing."
            DepartmentRouter.notify_unassigned_complaint(complaint)

        # Initial Status History entry
        initial_history = ComplaintStatusHistory(
            complaint_id=complaint.id,
            previous_status=None,
            new_status=complaint.status,
            changed_by_id=current_user.id,
            notes=f"Complaint registered. {status_note} AI Priority: {complaint.priority}."
        )
        db.session.add(initial_history)

        # Audit Log
        audit = AuditLog(
            user_id=current_user.id,
            action='COMPLAINT_FILED',
            resource_type='Complaint',
            resource_id=cid,
            ip_address=request.remote_addr,
            details=f"Complaint #{cid} created under category '{complaint.category}'."
        )
        db.session.add(audit)

        # Citizen In-app confirmation
        NotificationService.notify(
            user_id=current_user.id,
            title=f"Grievance Logged: #{cid}",
            message=f"Your complaint #{cid} has been registered and analyzed. Department: {target_dept.name if target_dept else 'Pending'}. 48h SLA active.",
            notification_type='status_change',
            link_url=f"/citizen/complaint/{cid}"
        )

        db.session.commit()
        flash(f"Complaint #{cid} successfully submitted! Tracking is now active.", "success")
        return redirect(url_for('citizen.view_complaint', complaint_id=cid))

    return render_template('citizen/file_complaint.html', form=form)

@citizen_bp.route('/my-complaints')
@login_required
@citizen_required
def my_complaints():
    """List citizen's complaints with filtering."""
    status = request.args.get('status')
    category = request.args.get('category')

    query = Complaint.query.filter_by(citizen_id=current_user.id)
    if status:
        query = query.filter_by(status=status)
    if category:
        query = query.filter_by(category=category)

    page = request.args.get('page', 1, type=int)
    pagination = query.order_by(Complaint.created_at.desc()).paginate(page=page, per_page=10, error_out=False)

    return render_template('citizen/my_complaints.html', pagination=pagination, status=status, category=category)

@citizen_bp.route('/complaint/<complaint_id>')
@login_required
@citizen_required
def view_complaint(complaint_id):
    """View detailed tracking view for a citizen's complaint."""
    complaint = Complaint.query.filter_by(complaint_id=complaint_id, citizen_id=current_user.id).first_or_404()
    reopen_form = ReopenComplaintForm()
    return render_template('citizen/view_complaint.html', complaint=complaint, reopen_form=reopen_form)

@citizen_bp.route('/complaint/<complaint_id>/confirm-resolution', methods=['POST'])
@login_required
@citizen_required
def confirm_resolution(complaint_id):
    """Citizen confirms and closes satisfactory resolution."""
    complaint = Complaint.query.filter_by(complaint_id=complaint_id, citizen_id=current_user.id).first_or_404()
    
    if complaint.status != 'Resolved — Awaiting Citizen Verification':
        flash('Only resolved grievances awaiting citizen verification can be confirmed.', 'warning')
        return redirect(url_for('citizen.view_complaint', complaint_id=complaint_id))

    old_status = complaint.status
    complaint.status = 'Closed'
    complaint.closed_at = utc_now()

    history = ComplaintStatusHistory(
        complaint_id=complaint.id,
        previous_status=old_status,
        new_status='Closed',
        changed_by_id=current_user.id,
        notes="Citizen verified that the public issue has been successfully resolved."
    )
    db.session.add(history)

    # Notify department official if assigned
    if complaint.assigned_staff_id:
        NotificationService.notify(
            user_id=complaint.assigned_staff_id,
            title=f"Citizen Verified Resolution: #{complaint.complaint_id}",
            message=f"Citizen {current_user.full_name} confirmed complete resolution for grievance #{complaint.complaint_id}. Ticket is now officially Closed.",
            notification_type='status_change',
            link_url=f"/department/complaint/{complaint.id}"
        )

    db.session.commit()
    flash(f'Thank you! Grievance #{complaint_id} has been marked as verified and closed.', 'success')
    return redirect(url_for('citizen.view_complaint', complaint_id=complaint_id))

@citizen_bp.route('/complaint/<complaint_id>/reopen', methods=['POST'])
@login_required
@citizen_required
def reopen_complaint(complaint_id):
    """Citizen requests reopening of an unresolved or poorly resolved complaint."""
    complaint = Complaint.query.filter_by(complaint_id=complaint_id, citizen_id=current_user.id).first_or_404()
    
    form = ReopenComplaintForm()
    if form.validate_on_submit():
        old_status = complaint.status
        complaint.status = 'Reopened'
        complaint.reopen_reason = form.reopen_reason.data.strip()
        complaint.reopen_count += 1
        
        # Reset SLA timers upon reopening
        now = utc_now()
        complaint.deadline_day2 = now + timedelta(hours=48)
        complaint.deadline_day4 = now + timedelta(hours=96)
        complaint.is_escalated_day2 = False
        complaint.is_escalated_day4 = False

        history = ComplaintStatusHistory(
            complaint_id=complaint.id,
            previous_status=old_status,
            new_status='Reopened',
            changed_by_id=current_user.id,
            notes=f"Citizen requested reopening. Reason: {complaint.reopen_reason}"
        )
        db.session.add(history)

        # Notify assigned staff or department supervisor
        if complaint.assigned_staff_id:
            NotificationService.notify(
                user_id=complaint.assigned_staff_id,
                title=f"REOPENED: Complaint #{complaint.complaint_id}",
                message=f"Citizen {current_user.full_name} rejected resolution for #{complaint.complaint_id}. Reason: {complaint.reopen_reason}",
                notification_type='escalation',
                link_url=f"/department/complaint/{complaint.id}"
            )

        db.session.commit()
        flash(f'Grievance #{complaint_id} has been reopened with supervisory notice.', 'warning')
        return redirect(url_for('citizen.view_complaint', complaint_id=complaint_id))

    flash('Please provide a valid reason for reopening.', 'danger')
    return redirect(url_for('citizen.view_complaint', complaint_id=complaint_id))

@citizen_bp.route('/complaint/<complaint_id>/edit', methods=['GET', 'POST'])
@login_required
@citizen_required
def edit_complaint(complaint_id):
    """Allow citizen to edit details only before official work starts."""
    complaint = Complaint.query.filter_by(complaint_id=complaint_id, citizen_id=current_user.id).first_or_404()
    
    # Restrict editing if work has progressed
    if complaint.status not in ('Submitted', 'Under AI Analysis', 'Awaiting Department Assignment', 'Assigned'):
        flash('Editing is locked once official departmental processing has started.', 'danger')
        return redirect(url_for('citizen.view_complaint', complaint_id=complaint_id))

    form = EditComplaintForm(obj=complaint)
    if form.validate_on_submit():
        complaint.title = form.title.data.strip()
        complaint.description = form.description.data.strip()
        complaint.address_landmark = form.address_landmark.data.strip()

        history = ComplaintStatusHistory(
            complaint_id=complaint.id,
            previous_status=complaint.status,
            new_status=complaint.status,
            changed_by_id=current_user.id,
            notes="Citizen updated grievance title, description, or address."
        )
        db.session.add(history)
        db.session.commit()
        flash('Complaint details updated successfully.', 'success')
        return redirect(url_for('citizen.view_complaint', complaint_id=complaint_id))

    return render_template('citizen/edit_complaint.html', form=form, complaint=complaint)
