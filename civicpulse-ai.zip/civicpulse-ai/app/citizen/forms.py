from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, FloatField, BooleanField, SubmitField, MultipleFileField
from wtforms.validators import DataRequired, Length, Optional
from app.auth.forms import INDIAN_STATES, CIVIC_CATEGORIES

class ComplaintSubmissionForm(FlaskForm):
    title = StringField('Complaint Title / Brief Summary', validators=[
        DataRequired(message="Please provide a clear title."),
        Length(min=5, max=150, message="Title must be between 5 and 150 characters.")
    ])
    category = SelectField('Category', choices=CIVIC_CATEGORIES, validators=[DataRequired()])
    description = TextAreaField('Detailed Problem Description', validators=[
        DataRequired(message="Please describe the civic issue in detail."),
        Length(min=15, max=2500, message="Description must be between 15 and 2500 characters.")
    ])
    state = SelectField('State / UT', choices=INDIAN_STATES, validators=[DataRequired()])
    district = StringField('District', validators=[
        DataRequired(message="District is required."),
        Length(min=2, max=60)
    ])
    city_village = StringField('City / Town / Village', validators=[
        DataRequired(message="City, town, or village is required."),
        Length(min=2, max=80)
    ])
    address_landmark = TextAreaField('Exact Address / Prominent Landmark', validators=[
        DataRequired(message="Please specify landmarks or street details to help field workers locate the problem."),
        Length(min=5, max=300)
    ])
    latitude = FloatField('Latitude', validators=[Optional()])
    longitude = FloatField('Longitude', validators=[Optional()])
    photos = MultipleFileField('Upload Photographs (Max 3, JPG/PNG/WEBP)', validators=[
        Optional()
    ])
    accuracy_consent = BooleanField('I certify that this information is accurate and pertains to a public civic issue.', validators=[
        DataRequired(message="Please confirm your report accuracy.")
    ])
    submit = SubmitField('Submit Grievance')

class ReopenComplaintForm(FlaskForm):
    reopen_reason = TextAreaField('Reason for Requesting Reopening', validators=[
        DataRequired(message="Please specify why the resolution is incomplete or unsatisfactory."),
        Length(min=10, max=500)
    ])
    submit = SubmitField('Submit Reopen Request')

class EditComplaintForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired(), Length(min=5, max=150)])
    description = TextAreaField('Description', validators=[DataRequired(), Length(min=15, max=2500)])
    address_landmark = TextAreaField('Address / Landmark', validators=[DataRequired(), Length(min=5, max=300)])
    submit = SubmitField('Save Updates')
