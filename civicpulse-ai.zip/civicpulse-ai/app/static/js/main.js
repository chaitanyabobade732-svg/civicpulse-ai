// CivicPulse AI — Interactive Frontend Logic

document.addEventListener('DOMContentLoaded', function () {
    // 1. Initialize Bootstrap Tooltips if available
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // 2. Real-Time Pre-Submission Duplicate Grievance Warning
    const titleInput = document.getElementById('title');
    const descInput = document.getElementById('description');
    const catSelect = document.getElementById('category');
    const latInput = document.getElementById('latitude');
    const lonInput = document.getElementById('longitude');
    const dupAlertContainer = document.getElementById('duplicate-warning-container');

    let debounceTimer;

    function checkForDuplicates() {
        if (!titleInput || !dupAlertContainer) return;

        const title = titleInput.value.trim();
        const description = descInput ? descInput.value.trim() : '';
        const category = catSelect ? catSelect.value : '';
        const latitude = latInput ? latInput.value : '';
        const longitude = lonInput ? lonInput.value : '';

        if (title.length < 6) {
            dupAlertContainer.style.display = 'none';
            dupAlertContainer.innerHTML = '';
            return;
        }

        fetch('/api/check-duplicates', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': document.querySelector('meta[name="csrf-token"]') ? document.querySelector('meta[name="csrf-token"]').content : ''
            },
            body: JSON.stringify({
                title: title,
                description: description,
                category: category,
                latitude: latitude,
                longitude: longitude
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.has_potential_duplicates && data.duplicates.length > 0) {
                let html = `
                <div class="duplicate-warning-box">
                    <div class="d-flex align-items-center gap-2 mb-2 text-danger fw-bold">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                        <span>Potential Similar Grievances Detected Nearby:</span>
                    </div>
                    <p class="small text-muted mb-2">
                        Other citizens have reported similar issues. You may still proceed with your submission, or track an existing complaint to prevent redundant field inspection:
                    </p>
                    <ul class="list-unstyled mb-0">`;
                
                data.duplicates.forEach(dup => {
                    html += `
                    <li class="border-top border-dark pt-2 mt-2 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge bg-dark border border-secondary text-light">${dup.complaint_id}</span>
                            <span class="fw-semibold ms-1 text-white">${dup.title}</span>
                            <div class="small text-muted">${dup.reasons.join(' • ')}</div>
                        </div>
                        <a href="/track?id=${dup.complaint_id}" target="_blank" class="btn btn-sm btn-outline-info">Track #</a>
                    </li>`;
                });
                
                html += `</ul></div>`;
                dupAlertContainer.innerHTML = html;
                dupAlertContainer.style.display = 'block';
            } else {
                dupAlertContainer.style.display = 'none';
                dupAlertContainer.innerHTML = '';
            }
        })
        .catch(err => {
            console.warn("Duplicate check error:", err);
        });
    }

    if (titleInput) {
        titleInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(checkForDuplicates, 600);
        });
    }

    if (catSelect) {
        catSelect.addEventListener('change', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(checkForDuplicates, 300);
        });
    }
});
