from datetime import datetime, timezone
from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from app.models import Complaint, Department, AIAnalysisResult, ComplaintStatusHistory, Escalation, utc_now
from app.services.analytics_service import AnalyticsService
from app.services.duplicate_detector import DuplicateDetector
from app.extensions import db

complaints_bp = Blueprint('complaints', __name__)

@complaints_bp.route('/')
def landing():
    """Main Public Landing Page."""
    stats = AnalyticsService.get_public_overview_stats()
    
    # Recent public complaints (Safe privacy display)
    recent_complaints = Complaint.query.filter(
        Complaint.status.notin_(['Rejected — With Reason'])
    ).order_by(Complaint.created_at.desc()).limit(6).all()
    
    return render_template('index.html', stats=stats, recent_complaints=recent_complaints)

@complaints_bp.route('/explore')
def explore():
    """Explore public grievances with privacy safeguards."""
    category = request.args.get('category')
    status = request.args.get('status')
    district = request.args.get('district')
    priority = request.args.get('priority')
    q = request.args.get('q')

    query = Complaint.query.filter(Complaint.status.notin_(['Rejected — With Reason']))

    if category:
        query = query.filter(Complaint.category == category)
    if status:
        query = query.filter(Complaint.status == status)
    if district:
        query = query.filter(Complaint.district.ilike(f"%{district}%"))
    if priority:
        query = query.filter(Complaint.priority == priority)
    if q:
        query = query.filter(
            (Complaint.title.ilike(f"%{q}%")) |
            (Complaint.complaint_id.ilike(f"%{q}%")) |
            (Complaint.city_village.ilike(f"%{q}%"))
        )

    page = request.args.get('page', 1, type=int)
    pagination = query.order_by(Complaint.created_at.desc()).paginate(page=page, per_page=12, error_out=False)

    return render_template(
        'complaints/explore.html',
        pagination=pagination,
        category=category,
        status=status,
        district=district,
        priority=priority,
        q=q
    )

@complaints_bp.route('/track', methods=['GET', 'POST'])
def track():
    """Track complaint progress by ID."""
    complaint_id = request.args.get('id') or (request.form.get('complaint_id') if request.method == 'POST' else None)
    
    complaint = None
    if complaint_id:
        clean_id = complaint_id.strip().upper()
        complaint = Complaint.query.filter_by(complaint_id=clean_id).first()
        if not complaint:
            flash(f"No grievance found matching ID '{clean_id}'. Please verify the tracking code.", 'warning')

    return render_template('complaints/track.html', complaint=complaint, searched_id=complaint_id)

@complaints_bp.route('/public-map')
def public_map():
    """Interactive Leaflet map showing public grievances and hotspots."""
    return render_template('complaints/public_map.html')

@complaints_bp.route('/analytics')
def public_analytics():
    """Public Accountability and Impact Dashboard."""
    stats = AnalyticsService.get_public_overview_stats()
    cat_distribution = AnalyticsService.get_category_distribution()
    dist_distribution = AnalyticsService.get_district_distribution()
    priority_distribution = AnalyticsService.get_priority_distribution()
    monthly_trends = AnalyticsService.get_monthly_trends()
    dept_performance = AnalyticsService.get_department_performance()

    return render_template(
        'complaints/public_analytics.html',
        stats=stats,
        cat_distribution=cat_distribution,
        dist_distribution=dist_distribution,
        priority_distribution=priority_distribution,
        monthly_trends=monthly_trends,
        dept_performance=dept_performance
    )

@complaints_bp.route('/api/map-data')
def api_map_data():
    """
    JSON endpoint for Leaflet map markers.
    Strictly safeguards citizen privacy: omits names, phone numbers, and private house data.
    """
    category = request.args.get('category')
    status = request.args.get('status')
    priority = request.args.get('priority')

    query = Complaint.query.filter(
        Complaint.latitude != None,
        Complaint.longitude != None,
        Complaint.status.notin_(['Rejected — With Reason'])
    )

    if category:
        query = query.filter(Complaint.category == category)
    if status:
        query = query.filter(Complaint.status == status)
    if priority:
        query = query.filter(Complaint.priority == priority)

    complaints = query.limit(200).all()

    points = []
    for c in complaints:
        points.append({
            'id': c.complaint_id,
            'title': c.title,
            'category': c.category,
            'status': c.status,
            'priority': c.priority,
            'lat': c.latitude,
            'lon': c.longitude,
            'district': c.district,
            'city': c.city_village,
            'landmark': c.address_landmark[:60] + ('...' if len(c.address_landmark) > 60 else ''),
            'created_at': c.created_at.strftime('%d %b %Y') if c.created_at else '',
            'is_escalated': c.is_escalated_day2 or c.is_escalated_day4,
            'track_url': url_for('complaints.track', id=c.complaint_id)
        })

    return jsonify({'count': len(points), 'features': points})

@complaints_bp.route('/api/check-duplicates', methods=['POST'])
def api_check_duplicates():
    """Real-time duplicate detection endpoint for pre-submission warnings."""
    data = request.get_json() or {}
    title = data.get('title', '')
    description = data.get('description', '')
    category = data.get('category', '')
    lat = data.get('latitude')
    lon = data.get('longitude')

    if not title or len(title.strip()) < 5:
        return jsonify({'duplicates': [], 'has_potential_duplicates': False})

    try:
        lat = float(lat) if lat is not None and lat != '' else None
        lon = float(lon) if lon is not None and lon != '' else None
    except (ValueError, TypeError):
        lat, lon = None, None

    duplicates = DuplicateDetector.find_potential_duplicates(
        title=title,
        description=description,
        category=category,
        lat=lat,
        lon=lon
    )

    return jsonify({
        'duplicates': duplicates,
        'has_potential_duplicates': len(duplicates) > 0
    })
