from app.complaints.routes import complaints_bp

__all__ = ['complaints_bp']
