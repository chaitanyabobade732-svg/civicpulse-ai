import csv
import io
from datetime import datetime, timezone
from flask import Blueprint, render_template, redirect, url_for, flash, request, Response, make_response
from flask_login import login_required, current_user
from app.auth.decorators import admin_required
from app.models import (
    User, Department, DepartmentMembership, DepartmentApplication,
    Complaint, AIAnalysisResult, Escalation, AuditLog, DuplicateGroup, utc_now
)
from app.services.escalation_service import EscalationService
from app.services.notification_service import NotificationService
from app.services.analytics_service import AnalyticsService
from app.extensions import db

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    """System Administration Control Center."""
    stats = AnalyticsService.get_public_overview_stats()
    pending_apps_count = DepartmentApplication.query.filter_by(status='pending').count()
    total_users = User.query.count()
    total_departments = Department.query.count()
    
    recent_applications = DepartmentApplication.query.filter_by(status='pending').order_by(DepartmentApplication.created_at.desc()).limit(5).all()
    recent_audits = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(8).all()
    recent_ai_logs = AIAnalysisResult.query.order_by(AIAnalysisResult.created_at.desc()).limit(6).all()

    return render_template(
        'admin/dashboard.html',
        stats=stats,
        pending_apps_count=pending_apps_count,
        total_users=total_users,
        total_departments=total_departments,
        recent_applications=recent_applications,
        recent_audits=recent_audits,
        recent_ai_logs=recent_ai_logs
    )

@admin_bp.route('/applications')
@login_required
@admin_required
def applications():
    """Review Department Access Applications."""
    status = request.args.get('status', 'pending')
    query = DepartmentApplication.query
    if status != 'all':
        query = query.filter_by(status=status)
    apps = query.order_by(DepartmentApplication.created_at.desc()).all()
    departments = Department.query.filter_by(is_active=True).all()
    return render_template('admin/department_applications.html', applications=apps, departments=departments, current_status=status)

@admin_bp.route('/applications/<int:app_id>/approve', methods=['POST'])
@login_required
@admin_required
def approve_application(app_id):
    """Approve a department official's registration and assign membership & role."""
    application = DepartmentApplication.query.get_or_404(app_id)
    notes = request.form.get('admin_notes', '').strip()
    role_to_grant = request.form.get('role', 'department_official') # 'department_official', 'supervisor', 'department_head'
    department_id = request.form.get('department_id', type=int)

    # If no department selected or matches, create or match
    if not department_id:
        # Try matching by name and category
        dept = Department.query.filter_by(name=application.department_name).first()
        if not dept:
            # Create department automatically
            dept_code = f"{application.department_category[:4].upper()}-{application.district[:3].upper()}"
            dept = Department(
                code=dept_code,
                name=application.department_name,
                category=application.department_category,
                state=application.state,
                district=application.district,
                jurisdiction_type='District',
                description=f"Jurisdiction: {application.jurisdiction}. Office: {application.office_address}"
            )
            db.session.add(dept)
            db.session.flush()
        department_id = dept.id

    applicant = application.applicant
    applicant.role = role_to_grant
    applicant.is_active = True

    # Create Department Membership
    membership = DepartmentMembership.query.filter_by(user_id=applicant.id).first()
    if not membership:
        membership = DepartmentMembership(
            user_id=applicant.id,
            department_id=department_id,
            designation=application.designation,
            office_address=application.office_address,
            employee_ref_no=application.employee_ref_no,
            is_supervisor=(role_to_grant == 'supervisor'),
            is_head=(role_to_grant == 'department_head')
        )
        db.session.add(membership)
    else:
        membership.department_id = department_id
        membership.designation = application.designation
        membership.is_supervisor = (role_to_grant == 'supervisor')
        membership.is_head = (role_to_grant == 'department_head')

    application.status = 'approved'
    application.admin_review_notes = notes
    application.reviewed_by_id = current_user.id
    application.reviewed_at = utc_now()

    # Audit Log
    audit = AuditLog(
        user_id=current_user.id,
        action='DEPARTMENT_APPLICATION_APPROVED',
        resource_type='DepartmentApplication',
        resource_id=str(application.id),
        ip_address=request.remote_addr,
        details=f"Approved official {applicant.full_name} for department id {department_id} with role '{role_to_grant}'."
    )
    db.session.add(audit)

    # Notify Applicant
    NotificationService.notify(
        user_id=applicant.id,
        title="Department Portal Access Approved",
        message=f"Congratulations! Your government credentials have been verified by Administrator. You now have full access as '{role_to_grant}'.",
        notification_type='system',
        link_url="/auth/dashboard"
    )

    db.session.commit()
    flash(f"Application #{app_id} for {applicant.full_name} has been verified and approved as {role_to_grant}.", "success")
    return redirect(url_for('admin.applications'))

@admin_bp.route('/applications/<int:app_id>/reject', methods=['POST'])
@login_required
@admin_required
def reject_application(app_id):
    """Reject a department registration application."""
    application = DepartmentApplication.query.get_or_404(app_id)
    notes = request.form.get('admin_notes', '').strip()

    if not notes:
        flash("A justification note is required to reject an official application.", "danger")
        return redirect(url_for('admin.applications'))

    application.status = 'rejected'
    application.admin_review_notes = notes
    application.reviewed_by_id = current_user.id
    application.reviewed_at = utc_now()

    applicant = application.applicant
    applicant.role = 'rejected_applicant'

    # Audit Log
    audit = AuditLog(
        user_id=current_user.id,
        action='DEPARTMENT_APPLICATION_REJECTED',
        resource_type='DepartmentApplication',
        resource_id=str(application.id),
        ip_address=request.remote_addr,
        details=f"Rejected official application for {applicant.email}. Reason: {notes}"
    )
    db.session.add(audit)

    # Notify Applicant
    NotificationService.notify(
        user_id=applicant.id,
        title="Department Portal Application Rejected",
        message=f"Your departmental registration could not be verified. Admin remarks: {notes}",
        notification_type='system',
        link_url="/auth/pending-verification"
    )

    db.session.commit()
    flash(f"Application #{app_id} rejected.", "warning")
    return redirect(url_for('admin.applications'))

@admin_bp.route('/trigger-escalations', methods=['POST'])
@login_required
@admin_required
def trigger_escalations():
    """Manual trigger to execute the Day 2 / Day 4 Escalation Engine."""
    result = EscalationService.process_all_escalations()
    flash(
        f"Escalation engine completed successfully! "
        f"Day 2 escalations triggered: {result['day2_escalations_triggered']}, "
        f"Day 4 escalations triggered: {result['day4_escalations_triggered']}.",
        "info"
    )
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/departments')
@login_required
@admin_required
def departments():
    """Manage civic departments and jurisdictions."""
    all_depts = Department.query.order_by(Department.category.asc(), Department.name.asc()).all()
    return render_template('admin/departments.html', departments=all_depts)

@admin_bp.route('/departments/create', methods=['POST'])
@login_required
@admin_required
def create_department():
    """Create a new department."""
    code = request.form.get('code', '').strip().upper()
    name = request.form.get('name', '').strip()
    category = request.form.get('category', '').strip()
    state = request.form.get('state', '').strip()
    district = request.form.get('district', '').strip()
    jurisdiction_type = request.form.get('jurisdiction_type', 'Municipal Corporation')
    contact_email = request.form.get('contact_email', '').strip()
    contact_phone = request.form.get('contact_phone', '').strip()

    if Department.query.filter_by(code=code).first():
        flash(f"Department code '{code}' already exists.", "danger")
        return redirect(url_for('admin.departments'))

    dept = Department(
        code=code,
        name=name,
        category=category,
        state=state,
        district=district,
        jurisdiction_type=jurisdiction_type,
        contact_email=contact_email,
        contact_phone=contact_phone
    )
    db.session.add(dept)
    db.session.commit()
    flash(f"Department '{name}' ({code}) registered successfully.", "success")
    return redirect(url_for('admin.departments'))

@admin_bp.route('/audit-logs')
@login_required
@admin_required
def audit_logs():
    """System-wide Security and Action Audit Logs."""
    page = request.args.get('page', 1, type=int)
    pagination = AuditLog.query.order_by(AuditLog.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin/audit_logs.html', pagination=pagination)

@admin_bp.route('/ai-logs')
@login_required
@admin_required
def ai_logs():
    """AI analysis logs and triage diagnostics."""
    page = request.args.get('page', 1, type=int)
    pagination = AIAnalysisResult.query.order_by(AIAnalysisResult.created_at.desc()).paginate(page=page, per_page=15, error_out=False)
    return render_template('admin/ai_logs.html', pagination=pagination)

@admin_bp.route('/export/complaints.csv')
@login_required
@admin_required
def export_complaints_csv():
    """Export complete grievance database to CSV format."""
    complaints = Complaint.query.order_by(Complaint.created_at.desc()).all()
    
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow([
        'Complaint ID', 'Title', 'Category', 'State', 'District', 'City/Village',
        'Status', 'Priority', 'Department Code', 'Day 2 Escalated', 'Day 4 Escalated',
        'Created At', 'Resolved At'
    ])

    for c in complaints:
        cw.writerow([
            c.complaint_id,
            c.title,
            c.category,
            c.state,
            c.district,
            c.city_village,
            c.status,
            c.priority,
            c.department.code if c.department else 'Unassigned',
            'Yes' if c.is_escalated_day2 else 'No',
            'Yes' if c.is_escalated_day4 else 'No',
            c.created_at.strftime('%Y-%m-%d %H:%M:%S') if c.created_at else '',
            c.resolved_at.strftime('%Y-%m-%d %H:%M:%S') if c.resolved_at else ''
        ])

    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = f"attachment; filename=civicpulse_complaints_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    output.headers["Content-type"] = "text/csv"
    return output
