from flask import current_app
from app.models import Notification, User
from app.extensions import db

class NotificationService:
    """Manages multi-channel civic grievance alerts with in-app tracking and simulated SMS/Email dispatch."""

    @staticmethod
    def notify(user_id, title, message, notification_type='status_change', link_url=None, simulate_sms=True, simulate_email=True):
        """
        Create in-app notification and simulate external dispatch.
        """
        user = User.query.get(user_id)
        if not user:
            return None

        # 1. In-App Notification
        notif = Notification(
            user_id=user_id,
            title=title,
            message=message,
            notification_type=notification_type,
            link_url=link_url,
            channel='in_app'
        )
        db.session.add(notif)

        # 2. Simulated SMS & Email delivery logging
        simulated = current_app.config.get('SIMULATE_NOTIFICATIONS', True)
        if simulated:
            if simulate_sms and user.mobile:
                current_app.logger.info(f"[SIMULATED SMS to +91-{user.mobile}]: {title} — {message}")
            if simulate_email and user.email:
                current_app.logger.info(f"[SIMULATED EMAIL to {user.email}]: Subject: {title} | Body: {message}")

        db.session.commit()
        return notif

    @staticmethod
    def mark_as_read(notification_id, user_id):
        """Mark specific notification as read."""
        notif = Notification.query.filter_by(id=notification_id, user_id=user_id).first()
        if notif:
            notif.is_read = True
            db.session.commit()
            return True
        return False

    @staticmethod
    def mark_all_as_read(user_id):
        """Mark all unread notifications for a user as read."""
        Notification.query.filter_by(user_id=user_id, is_read=False).update({'is_read': True})
        db.session.commit()
        return True
