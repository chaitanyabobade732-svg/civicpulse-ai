from datetime import datetime, timezone, timedelta
from sqlalchemy import func
from app.models import Complaint, Department, Escalation, utc_now
from app.extensions import db

class AnalyticsService:
    """Calculates live civic grievance metrics directly from database records."""

    @staticmethod
    def get_public_overview_stats():
        """Retrieve real metrics for landing page and public dashboard."""
        now = utc_now()
        total = Complaint.query.count()
        if total == 0:
            return {
                'total_complaints': 0,
                'open_complaints': 0,
                'in_progress_complaints': 0,
                'resolved_complaints': 0,
                'overdue_complaints': 0,
                'day2_escalations': 0,
                'day4_escalations': 0,
                'resolution_rate': 0.0,
                'avg_resolution_hours': 0.0,
                'is_empty': True
            }

        resolved = Complaint.query.filter(
            Complaint.status.in_(['Resolved — Awaiting Citizen Verification', 'Closed'])
        ).count()

        in_progress = Complaint.query.filter(
            Complaint.status.in_(['Acknowledged', 'In Progress', 'On Hold'])
        ).count()

        open_complaints = Complaint.query.filter(
            Complaint.status.in_(['Submitted', 'Under AI Analysis', 'Awaiting Department Assignment', 'Assigned', 'Reopened'])
        ).count()

        day2_escalations = Escalation.query.filter_by(escalation_level=2).count()
        day4_escalations = Escalation.query.filter_by(escalation_level=4).count()

        # Overdue count
        overdue = Complaint.query.filter(
            Complaint.status.notin_(['Resolved — Awaiting Citizen Verification', 'Closed', 'Rejected — With Reason']),
            Complaint.deadline_day2 != None,
            Complaint.deadline_day2 < now
        ).count()

        resolution_rate = round((resolved / total * 100), 1) if total > 0 else 0.0

        # Calculate average resolution time for resolved complaints
        resolved_records = Complaint.query.filter(
            Complaint.resolved_at != None,
            Complaint.created_at != None
        ).all()
        
        if resolved_records:
            total_hours = sum((c.resolved_at - c.created_at).total_seconds() / 3600.0 for c in resolved_records)
            avg_resolution_hours = round(total_hours / len(resolved_records), 1)
        else:
            avg_resolution_hours = 0.0

        return {
            'total_complaints': total,
            'open_complaints': open_complaints,
            'in_progress_complaints': in_progress,
            'resolved_complaints': resolved,
            'overdue_complaints': overdue,
            'day2_escalations': day2_escalations,
            'day4_escalations': day4_escalations,
            'resolution_rate': resolution_rate,
            'avg_resolution_hours': avg_resolution_hours,
            'is_empty': False
        }

    @staticmethod
    def get_category_distribution():
        """Retrieve count of complaints per category."""
        results = db.session.query(
            Complaint.category,
            func.count(Complaint.id).label('count')
        ).group_by(Complaint.category).order_by(func.count(Complaint.id).desc()).all()
        return [{'category': r[0], 'count': r[1]} for r in results]

    @staticmethod
    def get_district_distribution():
        """Retrieve count of complaints per district."""
        results = db.session.query(
            Complaint.district,
            func.count(Complaint.id).label('count')
        ).filter(Complaint.district != None).group_by(Complaint.district).order_by(func.count(Complaint.id).desc()).limit(10).all()
        return [{'district': r[0], 'count': r[1]} for r in results]

    @staticmethod
    def get_priority_distribution():
        """Retrieve count of complaints by priority."""
        results = db.session.query(
            Complaint.priority,
            func.count(Complaint.id).label('count')
        ).group_by(Complaint.priority).all()
        return [{'priority': r[0], 'count': r[1]} for r in results]

    @staticmethod
    def get_monthly_trends():
        """Retrieve complaint volume by month."""
        results = db.session.query(
            func.strftime('%Y-%m', Complaint.created_at).label('month'),
            func.count(Complaint.id).label('count')
        ).group_by('month').order_by('month').limit(6).all()
        return [{'month': r[0] if r[0] else 'Current', 'count': r[1]} for r in results]

    @staticmethod
    def get_department_performance():
        """Retrieve metrics per department."""
        now = utc_now()
        departments = Department.query.filter_by(is_active=True).all()
        data = []
        for d in departments:
            total_assigned = Complaint.query.filter_by(department_id=d.id).count()
            if total_assigned == 0:
                continue
            resolved = Complaint.query.filter(
                Complaint.department_id == d.id,
                Complaint.status.in_(['Resolved — Awaiting Citizen Verification', 'Closed'])
            ).count()
            overdue = Complaint.query.filter(
                Complaint.department_id == d.id,
                Complaint.status.notin_(['Resolved — Awaiting Citizen Verification', 'Closed', 'Rejected — With Reason']),
                Complaint.deadline_day2 != None,
                Complaint.deadline_day2 < now
            ).count()
            rate = round((resolved / total_assigned * 100), 1) if total_assigned > 0 else 0.0
            data.append({
                'id': d.id,
                'name': d.name,
                'category': d.category,
                'district': d.district,
                'total': total_assigned,
                'resolved': resolved,
                'overdue': overdue,
                'resolution_rate': rate
            })
        return sorted(data, key=lambda x: x['total'], reverse=True)
