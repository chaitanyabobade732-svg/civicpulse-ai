import math
import re
from datetime import datetime, timedelta, timezone
from app.models import Complaint, DuplicateGroup
from app.extensions import db

def haversine_distance_meters(lat1, lon1, lat2, lon2):
    """Calculate distance in meters between two geographical coordinates."""
    if lat1 is None or lon1 is None or lat2 is None or lon2 is None:
        return None
    R = 6371000 # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2.0) ** 2 + \
        math.cos(phi1) * math.cos(phi2) * \
        math.sin(delta_lambda / 2.0) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def tokenize(text):
    """Normalize and tokenize text into words, removing short stop words."""
    if not text:
        return set()
    words = re.findall(r'\b[a-z]{3,}\b', text.lower())
    stop_words = {'the', 'and', 'for', 'this', 'that', 'with', 'from', 'near', 'have', 'been', 'there', 'area', 'please', 'help'}
    return set(w for w in words if w not in stop_words)

def jaccard_similarity(tokens1, tokens2):
    """Calculate Jaccard similarity coefficient between two token sets."""
    if not tokens1 or not tokens2:
        return 0.0
    intersection = len(tokens1.intersection(tokens2))
    union = len(tokens1.union(tokens2))
    return intersection / union if union > 0 else 0.0

class DuplicateDetector:
    """Detects potential duplicate reports via text similarity, coordinates, and temporal window."""

    @staticmethod
    def find_potential_duplicates(title, description, category, lat=None, lon=None, exclude_id=None, days_lookback=30):
        """
        Check existing recent complaints for potential duplicates.
        Returns list of matching complaints with similarity scores and explanations.
        """
        cutoff_date = datetime.now(timezone.utc) - timedelta(days=days_lookback)
        
        query = Complaint.query.filter(
            Complaint.created_at >= cutoff_date,
            Complaint.status.notin_(['Rejected — With Reason'])
        )
        if exclude_id:
            query = query.filter(Complaint.id != exclude_id)
            
        candidates = query.all()
        query_tokens = tokenize(f"{title} {description}")
        
        results = []
        for cand in candidates:
            # 1. Text Similarity Score (0.0 to 1.0)
            cand_tokens = tokenize(f"{cand.title} {cand.description}")
            text_sim = jaccard_similarity(query_tokens, cand_tokens)
            
            # 2. Geo Proximity Score (0.0 to 1.0)
            geo_score = 0.0
            dist_meters = None
            if lat is not None and lon is not None and cand.latitude is not None and cand.longitude is not None:
                dist_meters = haversine_distance_meters(lat, lon, cand.latitude, cand.longitude)
                if dist_meters is not None:
                    if dist_meters <= 100: # Extremely close (<100m)
                        geo_score = 1.0
                    elif dist_meters <= 300: # Very close (<300m)
                        geo_score = 0.75
                    elif dist_meters <= 800: # Same neighborhood (<800m)
                        geo_score = 0.40
                    elif dist_meters <= 1500: # Same vicinity (<1.5km)
                        geo_score = 0.15

            # 3. Category Match Weight
            category_match = (cand.category == category)
            category_weight = 0.25 if category_match else 0.0

            # Composite Duplicate Confidence
            # If coordinates are present, balance text and spatial proximity
            if dist_meters is not None:
                composite_score = (0.45 * text_sim) + (0.40 * geo_score) + (0.15 * (1.0 if category_match else 0.0))
            else:
                # Text and category only
                composite_score = (0.75 * text_sim) + (0.25 * (1.0 if category_match else 0.0))

            if composite_score >= 0.35: # Candidate threshold
                reasons = []
                if text_sim >= 0.30:
                    reasons.append(f"High description similarity ({int(text_sim * 100)}%)")
                if dist_meters is not None and dist_meters <= 500:
                    reasons.append(f"Located within {int(dist_meters)} meters")
                if category_match:
                    reasons.append("Identical grievance category")

                results.append({
                    'complaint_id': cand.complaint_id,
                    'db_id': cand.id,
                    'title': cand.title,
                    'category': cand.category,
                    'status': cand.status,
                    'created_at': cand.created_at.strftime('%d %b %Y, %I:%M %p') if cand.created_at else '',
                    'distance_meters': round(dist_meters) if dist_meters is not None else None,
                    'similarity_score': round(composite_score, 2),
                    'reasons': reasons or ["General pattern overlap"]
                })

        # Sort descending by similarity score
        results.sort(key=lambda x: x['similarity_score'], reverse=True)
        return results[:5] # Return top 5 potential duplicates

    @staticmethod
    def link_duplicate(primary_id, duplicate_id, user_id=None, notes=None):
        """Link a complaint as a duplicate of an existing primary complaint."""
        # Check if already linked
        existing = DuplicateGroup.query.filter_by(
            primary_complaint_id=primary_id,
            duplicate_complaint_id=duplicate_id
        ).first()
        if not existing:
            link = DuplicateGroup(
                primary_complaint_id=primary_id,
                duplicate_complaint_id=duplicate_id,
                similarity_score=1.0,
                match_type='manual_link',
                marked_by_id=user_id,
                notes=notes or "Manually linked by department official/admin"
            )
            db.session.add(link)
            db.session.commit()
            return link
        return existing
