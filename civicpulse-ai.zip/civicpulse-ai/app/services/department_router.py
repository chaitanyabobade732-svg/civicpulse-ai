from app.models import Department, User, Notification
from app.extensions import db

class DepartmentRouter:
    """Routes complaints dynamically to the appropriate government department based on category and jurisdiction."""

    @staticmethod
    def route_complaint(category, state, district, city_village=None):
        """
        Determine target Department.
        1. Exact category match + same state + same district.
        2. Exact category match + same state.
        3. Exact category match anywhere (state-level or general).
        4. If no department matches category, return None (Awaiting Department Assignment).
        """
        # Try finding department matching category and district
        dept = Department.query.filter_by(
            category=category,
            state=state,
            district=district,
            is_active=True
        ).first()

        if dept:
            return dept

        # Try finding department matching category and state
        dept = Department.query.filter_by(
            category=category,
            state=state,
            is_active=True
        ).first()

        if dept:
            return dept

        # Fallback to any active department handling this category
        dept = Department.query.filter_by(
            category=category,
            is_active=True
        ).first()

        if dept:
            return dept

        # If still not found, check if a general grievance department exists
        general_dept = Department.query.filter(
            Department.category.in_(['Other Public Property', 'General Grievance Cell']),
            Department.is_active == True
        ).first()

        return general_dept # Could be None, which marks complaint as 'Awaiting Department Assignment'

    @staticmethod
    def notify_unassigned_complaint(complaint):
        """Notify all system administrators if a complaint could not be routed to any department."""
        admins = User.query.filter_by(role='admin', is_active=True).all()
        for admin in admins:
            notif = Notification(
                user_id=admin.id,
                title="Unassigned Complaint Requires Routing",
                message=f"Complaint #{complaint.complaint_id} in {complaint.district}, {complaint.state} could not be mapped to an active department. Manual routing required.",
                notification_type='assignment',
                link_url=f"/admin/complaints/{complaint.id}",
                channel='in_app'
            )
            db.session.add(notif)
        db.session.commit()
