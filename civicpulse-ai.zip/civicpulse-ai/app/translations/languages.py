from flask import session, current_app

TRANSLATIONS = {
    'en': {
        'brand_name': 'CivicPulse AI',
        'brand_tagline': 'Every Complaint Matters. Every Action Counts.',
        'nav_home': 'Home',
        'nav_explore': 'Explore Complaints',
        'nav_how_it_works': 'How It Works',
        'nav_map': 'Live Public Map',
        'nav_analytics': 'Impact Dashboard',
        'nav_track': 'Track Complaint',
        'nav_report': 'Report a Problem',
        'nav_login': 'Login',
        'nav_register': 'Create Account',
        'nav_dashboard': 'Dashboard',
        'nav_logout': 'Logout',
        'nav_notifications': 'Notifications',
        
        # Hero
        'hero_headline': 'Your City. Your Voice. Your Change.',
        'hero_subhead': 'Empowering Indian citizens with an AI-driven, transparent, and deadline-enforced public grievance resolution platform. Real accountability from report to repair.',
        'hero_cta_report': 'Report a Problem Now',
        'hero_cta_track': 'Track Your Complaint',
        
        # Statistics
        'stats_total_reported': 'Complaints Logged',
        'stats_resolved': 'Successfully Resolved',
        'stats_in_progress': 'Active Operations',
        'stats_resolution_rate': 'Resolution Efficiency',
        'stats_avg_time': 'Avg. Response Time',
        
        # Categories
        'cat_roads': 'Roads & Infrastructure',
        'cat_electricity': 'Electricity & Streetlights',
        'cat_garbage': 'Garbage & Sanitation',
        'cat_water': 'Water Supply',
        'cat_drainage': 'Drainage & Sewage',
        'cat_parks': 'Parks & Public Spaces',
        'cat_traffic': 'Traffic & Signals',
        'cat_buildings': 'Public Facilities',
        'cat_transport': 'Public Transport Infrastructure',
        'cat_other': 'Other Civic Issue',
        
        # Statuses
        'status_submitted': 'Submitted',
        'status_under_ai': 'Under AI Analysis',
        'status_awaiting_dept': 'Awaiting Department Assignment',
        'status_assigned': 'Assigned',
        'status_acknowledged': 'Acknowledged',
        'status_in_progress': 'In Progress',
        'status_on_hold': 'On Hold',
        'status_resolved_pending': 'Resolved — Awaiting Citizen Verification',
        'status_closed': 'Closed',
        'status_reopened': 'Reopened',
        'status_rejected': 'Rejected — With Reason',
        
        # Priorities
        'priority_low': 'Low',
        'priority_medium': 'Medium',
        'priority_high': 'High',
        'priority_urgent': 'Urgent Hazard',
        
        # Escalation
        'escalation_title': 'Day 2 & Day 4 Zero-Delay Escalation Guarantee',
        'escalation_day2_title': 'Day 2 Supervisor Escalation',
        'escalation_day2_desc': 'If no official action is initiated within 48 hours, the ticket automatically escalates directly to the Zonal Supervisor.',
        'escalation_day4_title': 'Day 4 Department Head Escalation',
        'escalation_day4_desc': 'If unresolved by 96 hours, the matter escalates to the Department Head with mandatory explanation required.',
        
        # Buttons & Common
        'btn_submit': 'Submit Complaint',
        'btn_confirm': 'Confirm Resolution',
        'btn_reopen': 'Request Reopening',
        'btn_filter': 'Apply Filters',
        'btn_reset': 'Reset',
        'empty_state_title': 'No Complaints Recorded',
        'empty_state_desc': 'There are currently no records matching this query in the database.'
    },
    'hi': {
        'brand_name': 'सिविकपल्स AI',
        'brand_tagline': 'हर शिकायत मायने रखती है। हर कार्रवाई गिनी जाती है।',
        'nav_home': 'मुख्य पृष्ठ',
        'nav_explore': 'शिकायतें देखें',
        'nav_how_it_works': 'यह कैसे काम करता है',
        'nav_map': 'लाइव सार्वजनिक नक्शा',
        'nav_analytics': 'प्रभाव डैशबोर्ड',
        'nav_track': 'शिकायत ट्रैक करें',
        'nav_report': 'समस्या दर्ज करें',
        'nav_login': 'लॉगिन',
        'nav_register': 'खाता बनाएं',
        'nav_dashboard': 'डैशबोर्ड',
        'nav_logout': 'लॉगआउट',
        'nav_notifications': 'सूचनाएं',
        
        # Hero
        'hero_headline': 'आपका शहर। आपकी आवाज़। आपका बदलाव।',
        'hero_subhead': 'भारतीय नागरिकों के लिए AI-संचालित, पारदर्शी और समयबद्ध सार्वजनिक शिकायत निवारण मंच। रिपोर्ट से लेकर समाधान तक वास्तविक जवाबदेही।',
        'hero_cta_report': 'अभी समस्या दर्ज करें',
        'hero_cta_track': 'शिकायत ट्रैक करें',
        
        # Statistics
        'stats_total_reported': 'कुल दर्ज शिकायतें',
        'stats_resolved': 'सफलतापूर्वक हल',
        'stats_in_progress': 'सक्रिय कार्य',
        'stats_resolution_rate': 'समाधान दर',
        'stats_avg_time': 'औसत प्रतिक्रिया समय',
        
        # Categories
        'cat_roads': 'सड़कें और बुनियादी ढांचा',
        'cat_electricity': 'बिजली और स्ट्रीटलाइट',
        'cat_garbage': 'कचरा और स्वच्छता',
        'cat_water': 'जल आपूर्ति',
        'cat_drainage': 'जल निकासी और सीवेज',
        'cat_parks': 'पार्क और सार्वजनिक स्थान',
        'cat_traffic': 'यातायात और सिग्नल',
        'cat_buildings': 'सार्वजनिक भवन',
        'cat_transport': 'सार्वजनिक परिवहन अवसंरचना',
        'cat_other': 'अन्य नागरिक मुद्दे',
        
        # Statuses
        'status_submitted': 'दर्ज की गई',
        'status_under_ai': 'AI विश्लेषण के तहत',
        'status_awaiting_dept': 'विभाग आवंटन की प्रतीक्षा',
        'status_assigned': 'आवंटित',
        'status_acknowledged': 'स्वीकृत',
        'status_in_progress': 'प्रगति पर है',
        'status_on_hold': 'अस्थायी रूप से रोका गया',
        'status_resolved_pending': 'समाधान हुआ — नागरिक सत्यापन प्रतीक्षित',
        'status_closed': 'बंद',
        'status_reopened': 'पुनः खोला गया',
        'status_rejected': 'कारण सहित अस्वीकृत',
        
        # Priorities
        'priority_low': 'निम्न',
        'priority_medium': 'मध्यम',
        'priority_high': 'उच्च',
        'priority_urgent': 'अति-आवश्यक खतरा',
        
        # Escalation
        'escalation_title': 'दिन 2 और दिन 4 शून्य-विलंब एस्केलेशन गारंटी',
        'escalation_day2_title': 'दिन 2 पर्यवेक्षक एस्केलेशन',
        'escalation_day2_desc': 'यदि 48 घंटों के भीतर कोई आधिकारिक कार्रवाई शुरू नहीं होती है, तो टिकट स्वतः क्षेत्रीय पर्यवेक्षक को प्रेषित हो जाता है।',
        'escalation_day4_title': 'दिन 4 विभागाध्यक्ष एस्केलेशन',
        'escalation_day4_desc': 'यदि 96 घंटों तक समाधान नहीं होता, तो मामला अनिवार्य स्पष्टीकरण के साथ विभागाध्यक्ष को प्रेषित होता है।',
        
        # Buttons & Common
        'btn_submit': 'शिकायत दर्ज करें',
        'btn_confirm': 'समाधान की पुष्टि करें',
        'btn_reopen': 'पुनः खोलने का अनुरोध करें',
        'btn_filter': 'फ़िल्टर लागू करें',
        'btn_reset': 'रीसेट',
        'empty_state_title': 'कोई शिकायत दर्ज नहीं है',
        'empty_state_desc': 'वर्तमान में डेटाबेस में इस खोज से मेल खाने वाला कोई रिकॉर्ड नहीं है।'
    },
    'mr': {
        'brand_name': 'सिव्हिकपल्स AI',
        'brand_tagline': 'प्रत्येक तक्रार महत्त्वाची. प्रत्येक कृती मोलाची.',
        'nav_home': 'मुख्यपृष्ठ',
        'nav_explore': 'तक्रारी पाहा',
        'nav_how_it_works': 'हे कसे कार्य करते',
        'nav_map': 'थेट नकाशा',
        'nav_analytics': 'प्रभाव डॅशबोर्ड',
        'nav_track': 'तक्रार ट्रॅक करा',
        'nav_report': 'समस्या नोंदवा',
        'nav_login': 'लॉगिन',
        'nav_register': 'खाते तयार करा',
        'nav_dashboard': 'डॅशबोर्ड',
        'nav_logout': 'लॉगआउट',
        'nav_notifications': 'सूचना',
        
        # Hero
        'hero_headline': 'तुमचे शहर. तुमचा आवाज. तुमचा बदल.',
        'hero_subhead': 'भारतीय नागरिकांसाठी AI-सक्षम, पारदर्शक आणि वेळेवर सार्वजनिक तक्रार निवारण व्यासपीठ. तक्रारीपासून निराकरणापर्यंत खरी जबाबदारी.',
        'hero_cta_report': 'आता तक्रार नोंदवा',
        'hero_cta_track': 'तक्रार तपासा',
        
        # Statistics
        'stats_total_reported': 'नोंदवलेल्या तक्रारी',
        'stats_resolved': 'यशस्वीरित्या सोडवलेल्या',
        'stats_in_progress': 'सुरू असलेले काम',
        'stats_resolution_rate': 'निवारण दर',
        'stats_avg_time': 'सरासरी प्रतिसाद वेळ',
        
        # Categories
        'cat_roads': 'रस्ते आणि पायाभूत सुविधा',
        'cat_electricity': 'वीज आणि पथदिवे',
        'cat_garbage': 'कचरा आणि स्वच्छता',
        'cat_water': 'पाणीपुरवठा',
        'cat_drainage': 'सांडपाणी आणि गटारे',
        'cat_parks': 'उद्याने आणि सार्वजनिक जागा',
        'cat_traffic': 'वाहतूक आणि सिग्नल',
        'cat_buildings': 'सार्वजनिक इमारती',
        'cat_transport': 'सार्वजनिक वाहतूक पायाभूत सुविधा',
        'cat_other': 'इतर नागरी समस्या',
        
        # Statuses
        'status_submitted': 'नोंदवली गेली',
        'status_under_ai': 'AI विश्लेषणाधीन',
        'status_awaiting_dept': 'विभाग वाटपाच्या प्रतीक्षेत',
        'status_assigned': 'नेमणूक केली',
        'status_acknowledged': 'स्वीकारली',
        'status_in_progress': 'काम सुरू आहे',
        'status_on_hold': 'तात्पुरते थांबवले',
        'status_resolved_pending': 'निवारण झाले — नागरिक पडताळणी प्रलंबित',
        'status_closed': 'बंद केले',
        'status_reopened': 'पुन्हा उघडले',
        'status_rejected': 'कारणासह नाकारले',
        
        # Priorities
        'priority_low': 'कमी',
        'priority_medium': 'मध्यम',
        'priority_high': 'उच्च',
        'priority_urgent': 'तातडीचा धोका',
        
        # Escalation
        'escalation_title': 'दिवस २ आणि दिवस ४ शून्य-विलंब एस्केलेशन हमी',
        'escalation_day2_title': 'दिवस २ पर्यवेक्षक एस्केलेशन',
        'escalation_day2_desc': '४८ तासांत कोणतीही कृती न झाल्यास, तक्रार थेट विभागीय पर्यवेक्षकाकडे पाठवली जाते.',
        'escalation_day4_title': 'दिवस ४ विभाग प्रमुख एस्केलेशन',
        'escalation_day4_desc': '९६ तासांत निवारण न झाल्यास, अनिवार्य स्पष्टीकरणासह प्रकरण विभाग प्रमुखांकडे सोपवले जाते.',
        
        # Buttons & Common
        'btn_submit': 'तक्रार सबमिट करा',
        'btn_confirm': 'निवारणाची खात्री करा',
        'btn_reopen': 'पुन्हा उघडण्याची विनंती करा',
        'btn_filter': 'फिल्टर लावा',
        'btn_reset': 'रीसेट',
        'empty_state_title': 'कोणत्याही तक्रारी आढळल्या नाहीत',
        'empty_state_desc': 'सध्या डेटाबेसमध्ये या शोधाशी जुळणाऱ्या तक्रारी नाहीत.'
    }
}

def get_current_language():
    """Retrieve current language from session, default to 'en'."""
    return session.get('language', 'en')

def translate(key, default=None):
    """Translate key based on session language with fallback to English."""
    lang = get_current_language()
    val = TRANSLATIONS.get(lang, {}).get(key)
    if val is not None:
        return val
    # Fallback to English
    val = TRANSLATIONS.get('en', {}).get(key)
    if val is not None:
        return val
    return default or key
