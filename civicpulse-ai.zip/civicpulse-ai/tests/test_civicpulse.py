import os
import unittest
from datetime import datetime, timezone, timedelta
from app import create_app
from app.extensions import db
from app.models import (
    User, Department, DepartmentMembership, DepartmentApplication,
    Complaint, AIAnalysisResult, Escalation, utc_now
)
from app.services.escalation_service import EscalationService
from app.services.duplicate_detector import DuplicateDetector
from app.services.department_router import DepartmentRouter
from app.services.ai_analyzer import AIComplaintAnalyzer

class CivicPulseTestCase(unittest.TestCase):

    def setUp(self):
        self.app = create_app('testing')
        self.app_context = self.app.app_context()
        self.app_context.push()
        self.client = self.app.test_client()
        db.create_all()

        # Seed sample department
        self.dept = Department(
            code='PWD-TEST',
            name='Public Works Department Test',
            category='Roads and Public Infrastructure',
            state='Maharashtra',
            district='Mumbai Suburban',
            jurisdiction_type='Municipal Corporation',
            sla_hours_day2=48,
            sla_hours_day4=96
        )
        db.session.add(self.dept)

        # Seed Administrator
        self.admin = User(
            email='admin@test.gov.in',
            full_name='Admin User',
            mobile='9820000001',
            role='admin',
            state='Maharashtra',
            district='Mumbai Suburban'
        )
        self.admin.set_password('AdminPass123!')
        db.session.add(self.admin)

        # Seed Citizen
        self.citizen = User(
            email='citizen@test.in',
            full_name='Citizen Tester',
            mobile='9820000002',
            role='citizen',
            state='Maharashtra',
            district='Mumbai Suburban'
        )
        self.citizen.set_password('CitizenPass123!')
        db.session.add(self.citizen)

        db.session.commit()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_landing_page(self):
        """Test landing page loads successfully."""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'CivicPulse', response.data)
        self.assertIn(b'Your City. Your Voice. Your Change.', response.data)

    def test_citizen_registration_and_role_protection(self):
        """Test citizen registration creates citizen and cannot access admin dashboard."""
        resp = self.client.post('/auth/register/citizen', data={
            'full_name': 'New Citizen',
            'email': 'newcitizen@test.in',
            'mobile': '9811122233',
            'password': 'Password123!',
            'confirm_password': 'Password123!',
            'state': 'Maharashtra',
            'district': 'Pune',
            'city_village': 'Kothrud',
            'preferred_language': 'en',
            'agree_terms': 'y'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)

        user = User.query.filter_by(email='newcitizen@test.in').first()
        self.assertIsNotNone(user)
        self.assertEqual(user.role, 'citizen')

        # Attempt to access protected admin dashboard as citizen -> should be denied
        admin_resp = self.client.get('/admin/dashboard', follow_redirects=True)
        self.assertIn(b'Access restricted', admin_resp.data)

    def test_department_pending_verification_security(self):
        """Test department registration is pending by default and cannot access department portal."""
        resp = self.client.post('/auth/register/department', data={
            'full_name': 'Official Applicant',
            'email': 'applicant@dept.gov.in',
            'mobile': '9822233344',
            'department_name': 'Electricity Board',
            'department_category': 'Electricity and Streetlights',
            'designation': 'Junior Engineer',
            'employee_ref_no': 'ELEC-902',
            'supervising_office': 'SE Office',
            'state': 'Maharashtra',
            'district': 'Mumbai Suburban',
            'jurisdiction': 'Zone 3',
            'office_address': 'Plot 4, MIDC Area',
            'reason': 'Handling street light repairs.',
            'password': 'OfficialPass123!',
            'confirm_password': 'OfficialPass123!',
            'official_declaration': 'y'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)

        app_user = User.query.filter_by(email='applicant@dept.gov.in').first()
        self.assertIsNotNone(app_user)
        self.assertEqual(app_user.role, 'department_applicant')

        # Check application status
        app_record = DepartmentApplication.query.filter_by(user_id=app_user.id).first()
        self.assertEqual(app_record.status, 'pending')

        # Attempt to access department portal while unverified -> redirected to pending verification
        dept_resp = self.client.get('/department/dashboard', follow_redirects=True)
        self.assertIn(b'Verification Pending', dept_resp.data)

    def test_admin_application_approval(self):
        """Test admin can approve pending department applicant."""
        # Create applicant
        app_user = User(
            email='engineer@pwd.gov.in',
            full_name='Er. Rajesh',
            mobile='9833344455',
            role='department_applicant',
            state='Maharashtra',
            district='Mumbai Suburban'
        )
        app_user.set_password('TestPass123!')
        db.session.add(app_user)
        db.session.flush()

        app_record = DepartmentApplication(
            user_id=app_user.id,
            department_name=self.dept.name,
            department_category=self.dept.category,
            designation='Assistant Engineer',
            employee_ref_no='PWD-404',
            state='Maharashtra',
            district='Mumbai Suburban',
            jurisdiction='Andheri Zone',
            office_address='PWD Office Andheri',
            reason='Manage road complaints',
            status='pending'
        )
        db.session.add(app_record)
        db.session.commit()

        # Login as Admin
        self.client.post('/auth/login', data={'email': 'admin@test.gov.in', 'password': 'AdminPass123!'})

        # Approve application
        approve_resp = self.client.post(f'/admin/applications/{app_record.id}/approve', data={
            'role': 'department_official',
            'department_id': self.dept.id,
            'admin_notes': 'Verified credentials against state employee database.'
        }, follow_redirects=True)
        self.assertEqual(approve_resp.status_code, 200)

        # Verify applicant is now approved
        updated_app = DepartmentApplication.query.get(app_record.id)
        self.assertEqual(updated_app.status, 'approved')
        self.assertEqual(app_user.role, 'department_official')

        membership = DepartmentMembership.query.filter_by(user_id=app_user.id).first()
        self.assertIsNotNone(membership)
        self.assertEqual(membership.department_id, self.dept.id)

    def test_complaint_routing_and_ai_fallback(self):
        """Test complaint creation, AI rule-based analysis, and department routing."""
        analyzer = AIComplaintAnalyzer()
        res = analyzer.analyze_complaint(
            title="Dangerous deep pothole on road",
            description="Huge crater pothole causing accidents near flyover.",
            user_category="Roads and Public Infrastructure"
        )
        self.assertEqual(res['recommended_category'], "Roads and Public Infrastructure")
        self.assertEqual(res['analysis_type'], "Rule-based analysis (External AI key not configured)")

        # Test Department Router
        target_dept = DepartmentRouter.route_complaint(
            category="Roads and Public Infrastructure",
            state="Maharashtra",
            district="Mumbai Suburban"
        )
        self.assertIsNotNone(target_dept)
        self.assertEqual(target_dept.id, self.dept.id)

    def test_duplicate_detection(self):
        """Test duplicate complaint detection logic."""
        now = utc_now()
        # Seed an existing complaint
        c1 = Complaint(
            complaint_id='CP-TEST-001',
            citizen_id=self.citizen.id,
            title='Large open pothole outside Metro station',
            description='Vehicles damaged by deep crater pothole outside metro entrance.',
            category='Roads and Public Infrastructure',
            state='Maharashtra',
            district='Mumbai Suburban',
            city_village='Andheri',
            address_landmark='Outside Metro Pillar 45',
            latitude=19.1190,
            longitude=72.8460,
            status='Assigned',
            created_at=now
        )
        db.session.add(c1)
        db.session.commit()

        # Check duplicate detector with similar report nearby (< 100 meters)
        dups = DuplicateDetector.find_potential_duplicates(
            title='Huge pothole crater near Metro pillar',
            description='Deep pothole damaging vehicles outside metro station.',
            category='Roads and Public Infrastructure',
            lat=19.1192,
            lon=72.8462
        )
        self.assertTrue(len(dups) > 0)
        self.assertEqual(dups[0]['complaint_id'], 'CP-TEST-001')
        self.assertGreater(dups[0]['similarity_score'], 0.5)

    def test_day2_and_day4_escalation_idempotency(self):
        """Test that Day 2 and Day 4 escalations trigger correctly and are idempotent."""
        past_time = utc_now() - timedelta(hours=100) # Passed both Day 2 (48h) and Day 4 (96h)
        
        c = Complaint(
            complaint_id='CP-TEST-ESC',
            citizen_id=self.citizen.id,
            title='Exposed live electrical cable',
            description='Sparking electrical cable on footpath.',
            category='Electricity and Streetlights',
            state='Maharashtra',
            district='Mumbai Suburban',
            city_village='Andheri',
            address_landmark='Pillar 12',
            status='Submitted', # Unresponsive status
            deadline_day2=past_time + timedelta(hours=48),
            deadline_day4=past_time + timedelta(hours=96),
            created_at=past_time
        )
        db.session.add(c)
        db.session.commit()

        # Run 1: Should trigger Day 2 and Day 4 escalations
        res1 = EscalationService.process_all_escalations()
        self.assertEqual(res1['day2_escalations_triggered'], 1)
        self.assertEqual(res1['day4_escalations_triggered'], 1)

        esc2 = Escalation.query.filter_by(complaint_id=c.id, escalation_level=2).count()
        esc4 = Escalation.query.filter_by(complaint_id=c.id, escalation_level=4).count()
        self.assertEqual(esc2, 1)
        self.assertEqual(esc4, 1)

        # Run 2: IDEMPOTENCY CHECK — running again must NOT create duplicate records!
        res2 = EscalationService.process_all_escalations()
        self.assertEqual(res2['day2_escalations_triggered'], 0)
        self.assertEqual(res2['day4_escalations_triggered'], 0)

        # Count in database must still be strictly 1 each!
        esc2_after = Escalation.query.filter_by(complaint_id=c.id, escalation_level=2).count()
        esc4_after = Escalation.query.filter_by(complaint_id=c.id, escalation_level=4).count()
        self.assertEqual(esc2_after, 1)
        self.assertEqual(esc4_after, 1)

    def test_api_check_duplicates_endpoint(self):
        """Test API endpoint for real-time duplicate grievance detection."""
        now = utc_now()
        c = Complaint(
            complaint_id='CP-DUP-TEST',
            citizen_id=self.citizen.id,
            title='Sewage water overflowing on main road',
            description='Severe sewage water leakage and contamination near junction.',
            category='Drainage and Sewage',
            state='Maharashtra',
            district='Mumbai Suburban',
            city_village='Bandra',
            address_landmark='Station Road',
            latitude=19.055,
            longitude=72.830,
            status='In Progress',
            created_at=now
        )
        db.session.add(c)
        db.session.commit()

        # Call duplicate check API with similar query
        response = self.client.post('/api/check-duplicates', json={
            'title': 'Sewage overflow on main road',
            'description': 'Water leaking from broken sewer line.',
            'category': 'Drainage and Sewage',
            'latitude': 19.056,
            'longitude': 72.831
        })
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertTrue(data['has_potential_duplicates'])
        self.assertTrue(len(data['duplicates']) > 0)
        self.assertEqual(data['duplicates'][0]['complaint_id'], 'CP-DUP-TEST')

    def test_api_map_data_privacy(self):
        """Test that public map data endpoint masks sensitive personal citizen information."""
        now = utc_now()
        c = Complaint(
            complaint_id='CP-MAP-TEST',
            citizen_id=self.citizen.id,
            title='Fallen tree blocking public road',
            description='Tree branch collapsed during storm.',
            category='Roads and Public Infrastructure',
            state='Maharashtra',
            district='Mumbai Suburban',
            city_village='Santacruz',
            address_landmark='Near Milan Subway',
            latitude=19.080,
            longitude=72.840,
            status='Assigned',
            priority='Urgent',
            created_at=now
        )
        db.session.add(c)
        db.session.commit()

        response = self.client.get('/api/map-data')
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertGreaterEqual(data['count'], 1)
        
        feature = [f for f in data['features'] if f['id'] == 'CP-MAP-TEST'][0]
        # Sensitive citizen personal data must NOT be present
        self.assertNotIn('citizen_name', feature)
        self.assertNotIn('mobile', feature)
        self.assertNotIn('citizen_email', feature)
        # Public data must be present
        self.assertEqual(feature['priority'], 'Urgent')
        self.assertEqual(feature['district'], 'Mumbai Suburban')

    def test_reopen_complaint_workflow(self):
        """Test citizen reopening an unsatisfactorily resolved complaint."""
        now = utc_now()
        c = Complaint(
            complaint_id='CP-REOPEN-TEST',
            citizen_id=self.citizen.id,
            title='Broken streetlight pole',
            description='Streetlight pole bent and dark.',
            category='Electricity and Streetlights',
            state='Maharashtra',
            district='Mumbai Suburban',
            city_village='Andheri',
            address_landmark='Lane 2',
            status='Resolved — Awaiting Citizen Verification',
            created_at=now - timedelta(days=2),
            deadline_day2=now + timedelta(hours=48),
            deadline_day4=now + timedelta(hours=96)
        )
        db.session.add(c)
        db.session.commit()

        # Login as citizen
        self.client.post('/auth/login', data={'email': 'citizen@test.in', 'password': 'CitizenPass123!'})

        # Submit reopen request
        resp = self.client.post(f'/citizen/complaint/{c.complaint_id}/reopen', data={
            'reopen_reason': 'The bulb was replaced but the broken pole is still leaning dangerously.'
        }, follow_redirects=True)
        self.assertEqual(resp.status_code, 200)

        updated_c = Complaint.query.get(c.id)
        self.assertEqual(updated_c.status, 'Reopened')
        self.assertEqual(updated_c.reopen_count, 1)
        self.assertIn('broken pole is still leaning', updated_c.reopen_reason)


if __name__ == '__main__':
    unittest.main()
